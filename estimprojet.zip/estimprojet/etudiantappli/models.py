from django.db import models

# Create your models here.
class Filiere(models.Model):
    code = models.CharField(max_length=3, null=True)
    libellet = models.CharField(max_length=25, null=True)
    
    def __str__(self):
        return self.libellet
    
class Niveau(models.Model):
    code = models.CharField(max_length=2, null=True)
    niveau = models.CharField(max_length=25, null=True)
    def __str__(self):
        return self.niveau
    

class Etudiant(models.Model):
    matricule = models.CharField(max_length=4, unique=True, blank=True)
    NomPrenom = models.CharField(max_length=50, null=True)
    option = models.ForeignKey(Filiere, on_delete=models.CASCADE)
    niveau = models.ForeignKey(Niveau, on_delete=models.CASCADE)
    GENRE = [("M", "Masculin"),("F","feminin")]
    genre = models.CharField(max_length=9, choices=GENRE, default="F")
    profil = models.FileField(upload_to="Imgetudiant")
    phone = models.CharField(max_length=9, null=True)
    
    def __str__(self):
        return f"{self.matricule} - {self.NomPrenom}"
    
class Information(models.Model):
    titre = models.CharField(max_length=25, null=True)
    description = models.TextField()
    image = models.FileField(upload_to = "ImgInfo")
    datepub = models.DateTimeField(auto_now_add = True)
    
    def __str__(self):
        return self.titre