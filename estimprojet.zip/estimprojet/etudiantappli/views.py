from django.shortcuts import render, redirect
from .models import *
# Create your views here.

def base(request):
    fil = Filiere.objects.all()
    Context = {"cles": fil}
    return render(request, "base.html", Context)

def etudiant(request):
    objetetudiant = Etudiant.objects.all()
    total_etudiant = objetetudiant.count()
    context = {
        'etudiant':objetetudiant,
        'totaletd':total_etudiant
    }
    return render(request, "etudiant.html", context)

def recherche(request):
    cherche = request.GET.get("cherche")
    etudiant = Etudiant.objects.filter(NomPrenom__contains=cherche)
    totalresultat = etudiant.count()
    messages = f'{totalresultat} resultats trouver'
    if totalresultat == 1:
        messages = f'{totalresultat} resultat trouver'
    if cherche =="":
        return redirect("pageinvalide")
    context = {
        'recherche':etudiant,
        'messages':messages
    }
    return render(request, "recherche.html", context)

def detail(request,id):
    detailobjet = Etudiant.objects.get(id=id)
    context = {
        'detail':detailobjet
    }
    return render(request, "detailetudiant.html", context)


def pageinvalide(request):
    messages = f'oups! recherche invalide, veillez saisir quelque chose'
    context = {
        'messages':messages
    }
    return render(request, "rechercheinvalide.html", context)


def information(request):
    infos = Information.objects.all().order_by('-id')
    context = {
        'infos':infos
    }
    return render(request, 'information.html', context)

def index(request):
    return render(request, 'index.html')