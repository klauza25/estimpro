from django.urls import path  
from .views import *


urlpatterns = [
    path('', index, name="index"),
    path("etud/", etudiant, name="etudiant"),
    path("rechercher/", recherche, name="recherche"),
    path("detail/<int:id>/", detail, name="detailetudiant"),
    path("rechercheinvalide/", pageinvalide, name="pageinvalide"),
    path("information/", information, name="information")

]